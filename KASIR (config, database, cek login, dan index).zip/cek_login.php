<?php
session_start();
include "config/konek.php";

$user  = $_POST['username'] ?? '';
$pass  = md5($_POST['password'] ?? '');
$akses = $_POST['role'] ?? '';

$login = mysqli_query($koneksi,
    "SELECT * FROM user 
     WHERE username='$user' 
     AND password='$pass' 
     AND role='$akses'"
);

$cek = mysqli_num_rows($login);

if ($cek > 0) {
    $data = mysqli_fetch_assoc($login);

    $_SESSION['UserID'] = $data['UserID'];
    $_SESSION['role']  = $data['role'];

    if ($data['role'] == 'Admin') {
        header("Location: admin/index1.php");
    } else if ($data['role'] == 'Kasir') {
        header("Location: kasir/index2.php");
    }
    exit;
} else {
    header("Location: index.php?pesan=gagal");
    exit;
}