<!-- =============================================== -->
<!-- FOOTER -->
<!-- =============================================== -->

<footer class="main-footer">

    <div class="pull-right hidden-xs">
        <b>Version</b> 1.26
    </div>

    <strong>
        Copyright &copy; 2026
        <a href="#">Kasir Sakti</a>.
    </strong>

    All rights reserved.

</footer>

<!-- =============================================== -->
<!-- SIDEBAR BACKGROUND -->
<!-- =============================================== -->

<div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- =============================================== -->
<!-- JAVASCRIPT -->
<!-- =============================================== -->

<!-- jQuery -->
<script src="../assets/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap -->
<script src="../assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- FastClick -->
<script src="../assets/bower_components/fastclick/lib/fastclick.js"></script>

<!-- SlimScroll -->
<script src="../assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>

<!-- Sparkline -->
<script src="../assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>

<!-- jvectormap -->
<script src="../assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

<script src="../assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

<!-- ChartJS -->
<script src="../assets/bower_components/chart.js/Chart.js"></script>

<!-- AdminLTE -->
<script src="../assets/dist/js/adminlte.min.js"></script>

<!-- Dashboard -->
<script src="../assets/dist/js/pages/dashboard2.js"></script>

<!-- Demo -->
<script src="../assets/dist/js/demo.js"></script>



</body>

</html>