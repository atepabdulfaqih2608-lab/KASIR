
<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Ambil Filter Tanggal
|--------------------------------------------------------------------------
*/

$dari   = $_GET['dari'] ?? '';
$sampai = $_GET['sampai'] ?? '';

/*
|--------------------------------------------------------------------------
| Query Data Laporan
|--------------------------------------------------------------------------
*/

$query = "
    SELECT
        penjualan.*,
        pelanggan.NamaPelanggan,
        user.NamaUser
    FROM penjualan

    LEFT JOIN pelanggan
        ON pelanggan.PelangganID = penjualan.PelangganID

    LEFT JOIN user
        ON user.UserID = penjualan.UserID
";

if ($dari != '' && $sampai != '') {

    $query .= "
        WHERE DATE(penjualan.TanggalPenjualan)
        BETWEEN '$dari' AND '$sampai'
    ";
}

$query .= "
    ORDER BY penjualan.PenjualanID DESC
";

$data = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html>

<head>

    <title>
        Cetak Laporan Transaksi
    </title>

    <style>

        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 40px;
        }

        .judul {
            text-align: center;
            margin-bottom: 30px;
        }

        .judul h2 {
            margin-bottom: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th,
        table td {
            border: 1px solid #000;
            padding: 10px;
            font-size: 14px;
        }

        table th {
            background-color: #f4f4f4;
        }

        .keterangan {
            text-align: center;
            margin-top: 40px;
            font-style: italic;
        }

    </style>

</head>

<body>

    <!-- ====================================== -->
    <!-- JUDUL -->
    <!-- ====================================== -->

    <div class="judul">

        <h2>
            KASIR SAKTI
        </h2>

        <p>
            Jl. Kertajati No. 123
        </p>

    </div>

    <!-- ====================================== -->
    <!-- TABEL -->
    <!-- ====================================== -->

    <table>

        <thead>

            <tr>

                <th width="5%">
                    NO
                </th>

                <th>
                    NOMOR TRANSAKSI
                </th>

                <th>
                    TANGGAL PENJUALAN
                </th>

                <th>
                    NAMA PELANGGAN
                </th>

                <th>
                    NAMA PETUGAS
                </th>

                <th>
                    TOTAL
                </th>

            </tr>

        </thead>

        <tbody>

            <?php
            $no = 1;
            $grandTotal = 0;

            while ($row = mysqli_fetch_array($data)) {

                $grandTotal += $row['TotalHarga'];
            ?>

                <tr>

                    <td>
                        <?= $no++; ?>
                    </td>

                    <td>
                        <?= $row['PenjualanID']; ?>
                    </td>

                    <td>
                        <?= $row['TanggalPenjualan']; ?>
                    </td>

                    <td>
                        <?= $row['NamaPelanggan']; ?>
                    </td>

                    <td>
                        <?= $row['NamaUser']; ?>
                    </td>

                    <td>

                        Rp.
                        <?= number_format(
                            $row['TotalHarga'],
                            0,
                            ',',
                            '.'
                        ); ?>

                    </td>

                </tr>

            <?php } ?>

        </tbody>

        <tfoot>

            <tr>

                <th colspan="5">
                    TOTAL SELURUH
                </th>

                <th>

                    Rp.
                    <?= number_format(
                        $grandTotal,
                        0,
                        ',',
                        '.'
                    ); ?>

                </th>

            </tr>

        </tfoot>

    </table>

    <!-- ====================================== -->
    <!-- KETERANGAN -->
    <!-- ====================================== -->

    <div class="keterangan">

        <?php if (!empty($dari) && !empty($sampai)) : ?>
        
            Laporan Transaksi Dari Tanggal
            <?= $dari; ?>
            Sampai
            <?= $sampai; ?>
        
        <?php else : ?>
        
            Laporan Semua Transaksi
        
        <?php endif; ?>
        
    </div>

    <script>
        window.print();
    </script>

</body>

</html>