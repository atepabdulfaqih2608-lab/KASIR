<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Filter Tanggal
|--------------------------------------------------------------------------
*/

$tgl_awal  = $_GET['tgl_awal'] ?? '';
$tgl_akhir = $_GET['tgl_akhir'] ?? '';

/*
|--------------------------------------------------------------------------
| Query Laporan
|--------------------------------------------------------------------------
*/

$query = "
    SELECT
        penjualan.*,
        pelanggan.NamaPelanggan,
        user.NamaUser
    FROM penjualan

    LEFT JOIN pelanggan
        ON pelanggan.PelangganID = penjualan.PelangganID

    LEFT JOIN user
        ON user.UserID = penjualan.UserID
";

if ($tgl_awal != '' && $tgl_akhir != '') {

    $query .= "
        WHERE DATE(penjualan.TanggalPenjualan)
        BETWEEN '$tgl_awal' AND '$tgl_akhir'
    ";
}

$query .= "
    ORDER BY penjualan.PenjualanID DESC
";

$data = mysqli_query($koneksi, $query);
?>

<div class="content-wrapper">

    <!-- ====================================== -->
    <!-- HEADER -->
    <!-- ====================================== -->

    <section class="content-header">

        <h1>
            Laporan Transaksi
        </h1>

    </section>

    <!-- ====================================== -->
    <!-- CONTENT -->
    <!-- ====================================== -->

    <section class="content">

        <div class="row">

            <!-- ====================================== -->
            <!-- FILTER -->
            <!-- ====================================== -->

            <div class="col-md-4">

                <div class="box box-primary">

                    <div class="box-header with-border">

                        <h3 class="box-title">
                            Filter Tanggal
                        </h3>

                    </div>

                    <form method="GET">

                        <div class="box-body">

                            <div class="form-group">

                                <label>
                                    Tanggal Awal
                                </label>

                                <input
                                    type="date"
                                    name="tgl_awal"
                                    class="form-control"
                                    value="<?= $tgl_awal; ?>"
                                    required
                                >

                            </div>

                            <div class="form-group">

                                <label>
                                    Tanggal Akhir
                                </label>

                                <input
                                    type="date"
                                    name="tgl_akhir"
                                    class="form-control"
                                    value="<?= $tgl_akhir; ?>"
                                    required
                                >

                            </div>

                        </div>

                        <div class="box-footer">

                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Filter
                            </button>

                        </div>

                    </form>

                </div>

            </div>

            <!-- ====================================== -->
            <!-- TABEL LAPORAN -->
            <!-- ====================================== -->

            <div class="col-md-8">

                <div class="box box-success">

                    <div class="box-header with-border">

                        <div class="pull-right">

                            <a
                                href="transaksi_laporan_excel.php?dari=<?= $tgl_awal; ?>&sampai=<?= $tgl_akhir; ?>"
                                target="_blank"
                                class="btn btn-success btn-sm"
                            >
                                <i class="fa fa-file-excel-o"></i>
                                EXCEL
                            </a>

                            <a
                                href="transaksi_laporan_csv.php?dari=<?= $tgl_awal; ?>&sampai=<?= $tgl_akhir; ?>"
                                target="_blank"
                                class="btn btn-info btn-sm"
                            >
                                <i class="fa fa-file-text-o"></i>
                                CSV
                            </a>

                            <a
                                href="transaksi_laporan_cetak.php?dari=<?= $tgl_awal; ?>&sampai=<?= $tgl_akhir; ?>"
                                target="_blank"
                                class="btn btn-primary btn-sm"
                            >
                                <i class="fa fa-print"></i>
                                CETAK
                            </a>

                        </div>

                    </div>

                    <div class="box-body table-responsive">

                        <table class="table table-bordered table-striped">

                            <thead>

                                <tr>

                                    <th width="5%">
                                        NO
                                    </th>

                                    <th>
                                        NOMOR TRANSAKSI
                                    </th>

                                    <th>
                                        TANGGAL PENJUALAN
                                    </th>

                                    <th>
                                        NAMA PELANGGAN
                                    </th>

                                    <th>
                                        NAMA PETUGAS
                                    </th>

                                    <th>
                                        TOTAL
                                    </th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php
                                $no = 1;

                                while ($row = mysqli_fetch_array($data)) {
                                ?>

                                    <tr>

                                        <td>
                                            <?= $no++; ?>
                                        </td>

                                        <td>
                                            <?= $row['PenjualanID']; ?>
                                        </td>

                                        <td>
                                            <?= $row['TanggalPenjualan']; ?>
                                        </td>

                                        <td>
                                            <?= $row['NamaPelanggan']; ?>
                                        </td>

                                        <td>
                                            <?= $row['NamaUser']; ?>
                                        </td>

                                        <td>

                                            Rp.
                                            <?= number_format(
                                                $row['TotalHarga'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </td>

                                    </tr>

                                <?php } ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </section>

</div>

<?php include "footer1.php"; ?>