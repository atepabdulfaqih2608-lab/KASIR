<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| SORTING
|--------------------------------------------------------------------------
*/

$sort = $_GET['sort'] ?? '';

switch ($sort) {

    case 'abjad':
        $order = "ORDER BY NamaPelanggan ASC";
        break;

    case 'za':
        $order = "ORDER BY NamaPelanggan DESC";
        break;

    case 'terbaru':
        $order = "ORDER BY PelangganID DESC";
        break;

    case 'terlama':
        $order = "ORDER BY PelangganID ASC";
        break;

    default:
        $order = "ORDER BY PelangganID DESC";
        break;
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA PELANGGAN
|--------------------------------------------------------------------------
*/

$queryPelanggan = mysqli_query(
    $koneksi,
    "SELECT * FROM pelanggan $order"
);
?>

<div class="content-wrapper">

    <!-- =========================================== -->
    <!-- HEADER -->
    <!-- =========================================== -->

    <section class="content-header">

        <h1>
            Data Pelanggan
            <small>Kasir Sederhana</small>
        </h1>

        <ol class="breadcrumb">

            <li>
                <a href="#">
                    <i class="fa fa-dashboard"></i>
                    Dashboard
                </a>
            </li>

            <li class="active">
                Data Pelanggan
            </li>

        </ol>

    </section>

    <!-- =========================================== -->
    <!-- CONTENT -->
    <!-- =========================================== -->

    <section class="content">

        <div class="box box-primary">

            <!-- HEADER BOX -->
            <div class="box-header">

                <button
                    type="button"
                    class="btn btn-primary"
                    data-toggle="modal"
                    data-target="#tambah-pelanggan">

                    <i class="glyphicon glyphicon-plus"></i>
                    Tambah Pelanggan

                </button>

            </div>

            <!-- BODY BOX -->
            <div class="box-body">
                <!-- SORTING -->
                <form method="GET" style="margin-bottom:15px; width:220px;">

                    <select
                        name="sort"
                        class="form-control"
                        onchange="this.form.submit()"
                    >

                        <option value=""
                            <?= ($sort == '') ? 'selected' : ''; ?>>
                            Urutkan Data
                        </option>

                        <option value="abjad"
                            <?= ($sort == 'abjad') ? 'selected' : ''; ?>>
                            Nama A-Z
                        </option>

                        <option value="za"
                            <?= ($sort == 'za') ? 'selected' : ''; ?>>
                            Nama Z-A
                        </option>

                        <option value="terbaru"
                            <?= ($sort == 'terbaru') ? 'selected' : ''; ?>>
                            Data Terbaru
                        </option>

                        <option value="terlama"
                            <?= ($sort == 'terlama') ? 'selected' : ''; ?>>
                            Data Terlama
                        </option>

                    </select>

                </form>

                <table class="table table-bordered table-striped">

                    <thead>

                        <tr>
                            <th width="5%">NO</th>
                            <th>Nama Pelanggan</th>
                            <th>Alamat</th>
                            <th>No. Telepon</th>
                            <th width="15%">Opsi</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php
                        $no = 1;

                        while ($pelanggan = mysqli_fetch_array($queryPelanggan)) {
                        ?>

                            <tr>

                                <td><?= $no++; ?></td>

                                <td>
                                    <?= $pelanggan['NamaPelanggan']; ?>
                                </td>

                                <td>
                                    <?= $pelanggan['Alamat']; ?>
                                </td>

                                <td>
                                    <?= $pelanggan['NomorTelepon']; ?>
                                </td>

                                <td>

                                    <!-- EDIT -->
                                    <button
                                        class="btn btn-warning btn-xs"
                                        data-toggle="modal"
                                        data-target="#edit<?= $pelanggan['PelangganID']; ?>">

                                        <i class="glyphicon glyphicon-edit"></i>

                                    </button>

                                    <!-- HAPUS -->

                                </td>

                            </tr>

                            <!-- =================================== -->
                            <!-- MODAL EDIT -->
                            <!-- =================================== -->

                            <div class="modal fade"
                                id="edit<?= $pelanggan['PelangganID']; ?>">

                                <div class="modal-dialog">

                                    <div class="modal-content">

                                        <div class="modal-header">

                                            <button
                                                type="button"
                                                class="close"
                                                data-dismiss="modal">

                                                &times;

                                            </button>

                                            <h4 class="modal-title">
                                                Edit Pelanggan
                                            </h4>

                                        </div>

                                        <div class="modal-body">

                                            <form action="pelanggan_update.php"
                                                method="POST">

                                                <input type="hidden"
                                                    name="id_pelanggan"
                                                    value="<?= $pelanggan['PelangganID']; ?>">

                                                <!-- Nama -->
                                                <div class="form-group">

                                                    <label>
                                                        Nama Pelanggan
                                                    </label>

                                                    <input type="text"
                                                        name="nm_pelanggan"
                                                        class="form-control"
                                                        value="<?= $pelanggan['NamaPelanggan']; ?>"
                                                        required>

                                                </div>

                                                <!-- Alamat -->
                                                <div class="form-group">

                                                    <label>
                                                        Alamat
                                                    </label>

                                                    <textarea
                                                        name="alamat"
                                                        class="form-control"
                                                        required><?= $pelanggan['Alamat']; ?></textarea>

                                                </div>

                                                <!-- Telepon -->
                                                <div class="form-group">

                                                    <label>
                                                        Nomor Telepon
                                                    </label>

                                                    <input type="text"
                                                        name="no_hp"
                                                        class="form-control"
                                                        value="<?= $pelanggan['NomorTelepon']; ?>"
                                                        required>

                                                </div>

                                                <button type="submit"
                                                    class="btn btn-primary">

                                                    Update

                                                </button>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>

<!-- =============================================== -->
<!-- MODAL TAMBAH -->
<!-- =============================================== -->

<div class="modal fade" id="tambah-pelanggan">

    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">

                <button
                    type="button"
                    class="close"
                    data-dismiss="modal">

                    &times;

                </button>

                <h4 class="modal-title">
                    Tambah Pelanggan
                </h4>

            </div>

            <div class="modal-body">

                <form action="pelanggan_proses.php"
                    method="POST">

                    <!-- Nama -->
                    <div class="form-group">

                        <label>
                            Nama Pelanggan
                        </label>

                        <input type="text"
                            name="nm_pelanggan"
                            class="form-control"
                            required>

                    </div>

                    <!-- Alamat -->
                    <div class="form-group">

                        <label>
                            Alamat
                        </label>

                        <textarea
                            name="alamat"
                            class="form-control"
                            required></textarea>

                    </div>

                    <!-- Telepon -->
                    <div class="form-group">

                        <label>
                            Nomor Telepon
                        </label>

                        <input type="text"
                            name="no_hp"
                            class="form-control"
                            required>

                    </div>

                    <button type="submit"
                        class="btn btn-primary">

                        Simpan

                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

<?php include "footer1.php"; ?>