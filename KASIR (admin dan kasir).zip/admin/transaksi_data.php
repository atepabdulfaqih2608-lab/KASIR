<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized');
}
?>

<div class="content-wrapper">

    <!-- ====================================== -->
    <!-- HEADER -->
    <!-- ====================================== -->

    <section class="content-header">

        <h1>
            Data Transaksi
            <small>Kasir Sederhana</small>
        </h1>

    </section>

    <!-- ====================================== -->
    <!-- CONTENT -->
    <!-- ====================================== -->

    <section class="content">

        <div class="box box-primary">

            <!-- HEADER BOX -->
            <div class="box-header">

                <a href="transaksi_tambah.php"
                    class="btn btn-primary">

                    <i class="glyphicon glyphicon-plus"></i>
                    Tambah Transaksi

                </a>

            </div>

            <!-- BODY -->
            <div class="box-body">
            <form method="GET" style="margin-bottom:15px; width:250px;">

               <select
                    name="sort"
                    class="form-control"
                    style="width:220px;"
                    onchange="this.form.submit()"
                >

                    <!-- DEFAULT -->
                    <option value=""
                        <?= (!isset($_GET['sort']) || $_GET['sort'] == '') ? 'selected' : ''; ?>>
                        Urutkan Data
                    </option>

                    <!-- ABJAD -->
                    <option value="abjad"
                        <?= ($sort == 'abjad') ? 'selected' : ''; ?>>
                        Abjad
                    </option>

                    <!-- TERMAHAL -->
                    <option value="termahal"
                        <?= ($sort == 'termahal') ? 'selected' : ''; ?>>
                        Total Termahal
                    </option>

                    <!-- TERMURAH -->
                    <option value="termurah"
                        <?= ($sort == 'termurah') ? 'selected' : ''; ?>>
                        Total Termurah
                    </option>

                </select>

            </form>

                <table class="table table-bordered table-striped">

                    <thead>

                        <tr>
                            <th width="5%">NO</th>
                            <th>No Transaksi</th>
                            <th>Tanggal</th>
                            <th>Pelanggan</th>
                            <th>Kasir</th>
                            <th>Total</th>
                            <th width="18%">Opsi</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php

                        $sort = $_GET['sort'] ?? 'urutkan';

                        switch ($sort) {
                        
                            // =========================
                            // BERDASARKAN NAMA PELANGGAN
                            // =========================
                            case 'abjad':
                                $order = "ORDER BY pelanggan.NamaPelanggan ASC";
                                break;

                            // =========================
                            // TOTAL TERMAHAL
                            // =========================
                            case 'termahal':
                                $order = "ORDER BY penjualan.TotalHarga DESC";
                                break;
                            
                            // =========================
                            // TOTAL TERMURAH
                            // =========================
                            case 'termurah':
                                $order = "ORDER BY penjualan.TotalHarga ASC";
                                break;
                            
                            default:
                                $order = "ORDER BY penjualan.PenjualanID DESC";
                                break;
                        }

                        $query = mysqli_query(
                            $koneksi,
                            "SELECT *
                            FROM penjualan
                            INNER JOIN pelanggan
                                ON pelanggan.PelangganID = penjualan.PelangganID
                            INNER JOIN user
                                ON user.UserID = penjualan.UserID
                            $order"
                        );

                        $no = 1;

                        while ($data = mysqli_fetch_array($query)) {
                        ?>

                            <tr>

                                <td><?= $no++; ?></td>

                                <td>
                                    <?= $data['PenjualanID']; ?>
                                </td>

                                <td>
                                    <?= $data['TanggalPenjualan']; ?>
                                </td>

                                <td>
                                    <?= $data['NamaPelanggan']; ?>
                                </td>

                                <td>
                                    <?= $data['NamaUser']; ?>
                                </td>

                                <td>

                                    Rp
                                    <?= number_format(
                                        $data['TotalHarga'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>

                                </td>

                                <td>

                                    <!-- DETAIL -->
                                    <a href="transaksi_detail.php?PenjualanID=<?= $data['PenjualanID']; ?>"
                                        class="btn btn-info btn-xs">

                                        <i class="glyphicon glyphicon-eye-open"></i>

                                    </a>

                                    <!-- CETAK -->
                                    <a href="transaksi_cetak.php?PenjualanID=<?= $data['PenjualanID']; ?>"
                                        target="_blank"
                                        class="btn btn-success btn-xs">

                                        <i class="glyphicon glyphicon-print"></i>

                                    </a>

                                    <!-- HAPUS -->
                                    <a href="transaksi_hapus.php?PenjualanID=<?= $data['PenjualanID']; ?>"
                                        class="btn btn-danger btn-xs"
                                        onclick="return confirm('Yakin hapus transaksi ini?')">

                                        <i class="glyphicon glyphicon-trash"></i>

                                    </a>

                                </td>

                            </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>

<?php include "footer1.php"; ?>