<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Cek Parameter UserID
|--------------------------------------------------------------------------
*/
if (!isset($_GET['UserID'])) {
    die('UserID tidak ditemukan');
}

$UserID = $_GET['UserID'];

/*
|--------------------------------------------------------------------------
| Hapus User
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "DELETE FROM user WHERE UserID = '$UserID'"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal menghapus user : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: kasir_data.php");
exit;
?>