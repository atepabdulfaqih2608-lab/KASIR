<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Validasi ID Detail
|--------------------------------------------------------------------------
*/
if (!isset($_GET['DetailID'])) {
    die('Detail transaksi tidak ditemukan');
}

$DetailID = $_GET['DetailID'];

/*
|--------------------------------------------------------------------------
| Ambil Data Detail Transaksi
|--------------------------------------------------------------------------
*/
$queryDetail = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    WHERE DetailID = '$DetailID'"
);

if (mysqli_num_rows($queryDetail) == 0) {
    die('Data detail transaksi tidak ditemukan');
}

$detail = mysqli_fetch_array($queryDetail);

$ProdukID = $detail['ProdukID'];
$Jumlah   = $detail['JumlahProduk'];

/*
|--------------------------------------------------------------------------
| Ambil Data Produk
|--------------------------------------------------------------------------
*/
$queryProduk = mysqli_query(
    $koneksi,
    "SELECT *
    FROM produk
    WHERE ProdukID = '$ProdukID'"
);

if (mysqli_num_rows($queryProduk) == 0) {
    die('Produk tidak ditemukan');
}

$produk = mysqli_fetch_array($queryProduk);

$StokSekarang = $produk['Stok'];

/*
|--------------------------------------------------------------------------
| Kembalikan Stok
|--------------------------------------------------------------------------
*/
$StokBaru = $StokSekarang + $Jumlah;

$queryUpdateStok = mysqli_query(
    $koneksi,
    "UPDATE produk SET
        Stok = '$StokBaru'
    WHERE ProdukID = '$ProdukID'"
);

if (!$queryUpdateStok) {
    die('Gagal mengembalikan stok : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Hapus Item Keranjang
|--------------------------------------------------------------------------
*/
$queryHapus = mysqli_query(
    $koneksi,
    "DELETE FROM detailpenjualan
    WHERE DetailID = '$DetailID'"
);

if (!$queryHapus) {
    die('Gagal menghapus item : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
echo "
<script>
    alert('Item berhasil dihapus!');
    window.location='transaksi_tambah.php';
</script>
";
exit;
?>
