<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$NamaProduk = trim($_POST['NamaProduk']);
$Harga      = trim($_POST['Harga']);
$Stok       = trim($_POST['Stok']);

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($NamaProduk) ||
    $Harga === '' ||
    $Stok === ''
) {
    die('Semua data wajib diisi');
}

/*
|--------------------------------------------------------------------------
| Validasi Angka
|--------------------------------------------------------------------------
*/
if ($Harga < 0) {
    die('Harga tidak boleh minus');
}

if ($Stok < 0) {
    die('Stok tidak boleh minus');
}

/*
|--------------------------------------------------------------------------
| Simpan Produk
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "INSERT INTO produk
    (
        NamaProduk,
        Harga,
        Stok
    )
    VALUES
    (
        '$NamaProduk',
        '$Harga',
        '$Stok'
    )"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal menambahkan produk : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: produk_data.php");
exit;
?>