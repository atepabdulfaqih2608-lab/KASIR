
<?php
require_once __DIR__ . '/../config/konek.php';

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Transaksi.xls");

$dari   = $_GET['dari'] ?? '';
$sampai = $_GET['sampai'] ?? '';

$query = "
    SELECT
        penjualan.*,
        pelanggan.NamaPelanggan,
        user.NamaUser
    FROM penjualan

    LEFT JOIN pelanggan
        ON pelanggan.PelangganID = penjualan.PelangganID

    LEFT JOIN user
        ON user.UserID = penjualan.UserID
";

if ($dari != '' && $sampai != '') {

    $query .= "
        WHERE DATE(penjualan.TanggalPenjualan)
        BETWEEN '$dari' AND '$sampai'
    ";
}

$query .= "
    ORDER BY penjualan.PenjualanID DESC
";

$data = mysqli_query($koneksi, $query);
?>

<h2>
    LAPORAN TRANSAKSI
</h2>

<p>
    Dari Tanggal <?= $dari; ?>
    Sampai <?= $sampai; ?>
</p>

<table border="1">

    <thead>

        <tr>

            <th>NO</th>
            <th>NOMOR TRANSAKSI</th>
            <th>TANGGAL</th>
            <th>PELANGGAN</th>
            <th>PETUGAS</th>
            <th>TOTAL</th>

        </tr>

    </thead>

    <tbody>

        <?php
        $no = 1;
        $grandTotal = 0;

        while ($row = mysqli_fetch_array($data)) {

            $grandTotal += $row['TotalHarga'];
        ?>

            <tr>

                <td><?= $no++; ?></td>

                <td>
                    <?= $row['PenjualanID']; ?>
                </td>

                <td>
                    <?= $row['TanggalPenjualan']; ?>
                </td>

                <td>
                    <?= $row['NamaPelanggan']; ?>
                </td>

                <td>
                    <?= $row['NamaUser']; ?>
                </td>

                <td>
                    <?= $row['TotalHarga']; ?>
                </td>

            </tr>

        <?php } ?>

    </tbody>

    <tfoot>

        <tr>

            <th colspan="5">
                TOTAL
            </th>

            <th>
                <?= $grandTotal; ?>
            </th>

        </tr>

    </tfoot>

</table>