<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$NamaUser = trim($_POST['NamaUser']);
$username = trim($_POST['username']);
$password = trim($_POST['password']);
$role     = trim($_POST['role']);

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($NamaUser) ||
    empty($username) ||
    empty($password) ||
    empty($role)
) {
    die('Semua data wajib diisi');
}

/*
|--------------------------------------------------------------------------
| Cek Username Sudah Ada
|--------------------------------------------------------------------------
*/
$cekUsername = mysqli_query(
    $koneksi,
    "SELECT * FROM user WHERE username = '$username'"
);

if (mysqli_num_rows($cekUsername) > 0) {
    die('Username sudah digunakan');
}

/*
|--------------------------------------------------------------------------
| Enkripsi Password
|--------------------------------------------------------------------------
*/
$passwordHash = md5($password);

/*
|--------------------------------------------------------------------------
| Simpan Data
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "INSERT INTO user
    (
        NamaUser,
        username,
        password,
        role
    )
    VALUES
    (
        '$NamaUser',
        '$username',
        '$passwordHash',
        '$role'
    )"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal menambahkan user : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: kasir_data.php");
exit;
?>