<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$ProdukID   = trim($_POST['ProdukID']);
$NamaProduk = trim($_POST['NamaProduk']);
$Harga      = trim($_POST['Harga']);
$Stok       = trim($_POST['Stok']);

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($ProdukID) ||
    empty($NamaProduk) ||
    $Harga === '' ||
    $Stok === ''
) {
    die('Data tidak lengkap');
}

/*
|--------------------------------------------------------------------------
| Validasi Angka
|--------------------------------------------------------------------------
*/
if ($Harga < 0) {
    die('Harga tidak boleh minus');
}

if ($Stok < 0) {
    die('Stok tidak boleh minus');
}

/*
|--------------------------------------------------------------------------
| Update Produk
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "UPDATE produk SET
        NamaProduk = '$NamaProduk',
        Harga      = '$Harga',
        Stok       = '$Stok'
    WHERE ProdukID = '$ProdukID'"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal update produk : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: produk_data.php");
exit;
?>