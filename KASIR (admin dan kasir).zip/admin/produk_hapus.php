<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Validasi ProdukID
|--------------------------------------------------------------------------
*/
if (!isset($_GET['ProdukID'])) {
    die('ProdukID tidak ditemukan');
}

$ProdukID = $_GET['ProdukID'];

/*
|--------------------------------------------------------------------------
| Hapus Produk
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "DELETE FROM produk
    WHERE ProdukID = '$ProdukID'"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal menghapus produk : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: produk_data.php");
exit;
?>