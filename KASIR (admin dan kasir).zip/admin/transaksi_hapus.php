<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Validasi ID
|--------------------------------------------------------------------------
*/
if (!isset($_GET['PenjualanID'])) {
    die('ID transaksi tidak ditemukan');
}

$PenjualanID = $_GET['PenjualanID'];

/*
|--------------------------------------------------------------------------
| Cek Data Transaksi
|--------------------------------------------------------------------------
*/
$queryPenjualan = mysqli_query(
    $koneksi,
    "SELECT *
    FROM penjualan
    WHERE PenjualanID = '$PenjualanID'"
);

if (mysqli_num_rows($queryPenjualan) == 0) {
    die('Data transaksi tidak ditemukan');
}

/*
|--------------------------------------------------------------------------
| Ambil Semua Detail Barang
|--------------------------------------------------------------------------
*/
$queryDetail = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    WHERE PenjualanID = '$PenjualanID'"
);

/*
|--------------------------------------------------------------------------
| Kembalikan Stok Produk
|--------------------------------------------------------------------------
*/
while ($detail = mysqli_fetch_array($queryDetail)) {

    $ProdukID = $detail['ProdukID'];
    $Jumlah   = $detail['JumlahProduk'];

    /*
    |--------------------------------------------------------------------------
    | Ambil Stok Sekarang
    |--------------------------------------------------------------------------
    */
    $queryProduk = mysqli_query(
        $koneksi,
        "SELECT *
        FROM produk
        WHERE ProdukID = '$ProdukID'"
    );

    $produk = mysqli_fetch_array($queryProduk);

    $StokSekarang = $produk['Stok'];

    /*
    |--------------------------------------------------------------------------
    | Hitung Stok Baru
    |--------------------------------------------------------------------------
    */
    $StokBaru = $StokSekarang + $Jumlah;

    /*
    |--------------------------------------------------------------------------
    | Update Stok
    |--------------------------------------------------------------------------
    */
    $updateStok = mysqli_query(
        $koneksi,
        "UPDATE produk SET
            Stok = '$StokBaru'
        WHERE ProdukID = '$ProdukID'"
    );

    if (!$updateStok) {
        die('Gagal mengembalikan stok : ' . mysqli_error($koneksi));
    }
}

/*
|--------------------------------------------------------------------------
| Hapus Detail Transaksi
|--------------------------------------------------------------------------
*/
$hapusDetail = mysqli_query(
    $koneksi,
    "DELETE FROM detailpenjualan
    WHERE PenjualanID = '$PenjualanID'"
);

if (!$hapusDetail) {
    die('Gagal menghapus detail transaksi : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Hapus Penjualan
|--------------------------------------------------------------------------
*/
$hapusPenjualan = mysqli_query(
    $koneksi,
    "DELETE FROM penjualan
    WHERE PenjualanID = '$PenjualanID'"
);

if (!$hapusPenjualan) {
    die('Gagal menghapus transaksi : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
echo "
<script>
    alert('Transaksi berhasil dihapus!');
    window.location='transaksi_data.php';
</script>
";
exit;
?>
