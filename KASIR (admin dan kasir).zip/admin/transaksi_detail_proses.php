<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$PenjualanID = trim($_POST['no_trans']);
$ProdukID    = trim($_POST['produk']);
$Jumlah      = trim($_POST['jumlah']);

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($PenjualanID) ||
    empty($ProdukID) ||
    empty($Jumlah)
) {
    die('Data transaksi tidak lengkap');
}

/*
|--------------------------------------------------------------------------
| Validasi Jumlah
|--------------------------------------------------------------------------
*/
if ($Jumlah <= 0) {
    die('Jumlah harus lebih dari 0');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Produk
|--------------------------------------------------------------------------
*/
$queryProduk = mysqli_query(
    $koneksi,
    "SELECT * FROM produk
    WHERE ProdukID = '$ProdukID'"
);

if (mysqli_num_rows($queryProduk) == 0) {
    die('Produk tidak ditemukan');
}

$produk = mysqli_fetch_array($queryProduk);

$Harga = $produk['Harga'];
$Stok  = $produk['Stok'];

/*
|--------------------------------------------------------------------------
| Cek Stok
|--------------------------------------------------------------------------
*/
if ($Jumlah > $Stok) {

    echo "
    <script>
        alert('Stok tidak mencukupi!');
        window.location='transaksi_tambah.php';
    </script>
    ";

    exit;
}

/*
|--------------------------------------------------------------------------
| Hitung Subtotal
|--------------------------------------------------------------------------
*/
$Subtotal = $Harga * $Jumlah;

/*
|--------------------------------------------------------------------------
| Cek Produk Sudah Ada Di Keranjang
|--------------------------------------------------------------------------
*/
$queryCek = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    WHERE PenjualanID = '$PenjualanID'
    AND ProdukID = '$ProdukID'"
);

/*
|--------------------------------------------------------------------------
| Jika Produk Sudah Ada
|--------------------------------------------------------------------------
*/
if (mysqli_num_rows($queryCek) > 0) {

    $detailLama = mysqli_fetch_array($queryCek);

    $JumlahLama = $detailLama['JumlahProduk'];
    $SubtotalLama = $detailLama['Subtotal'];

    $JumlahBaru = $JumlahLama + $Jumlah;
    $SubtotalBaru = $SubtotalLama + $Subtotal;

    /*
    |--------------------------------------------------------------------------
    | Update Keranjang
    |--------------------------------------------------------------------------
    */
    $queryUpdate = mysqli_query(
        $koneksi,
        "UPDATE detailpenjualan SET
            JumlahProduk = '$JumlahBaru',
            Subtotal     = '$SubtotalBaru'
        WHERE DetailID = '{$detailLama['DetailID']}'"
    );

    if (!$queryUpdate) {
        die('Gagal update keranjang : ' . mysqli_error($koneksi));
    }

} else {

    /*
    |--------------------------------------------------------------------------
    | Simpan Detail Baru
    |--------------------------------------------------------------------------
    */
    $queryInsert = mysqli_query(
        $koneksi,
        "INSERT INTO detailpenjualan
        (
            PenjualanID,
            ProdukID,
            JumlahProduk,
            Subtotal
        )
        VALUES
        (
            '$PenjualanID',
            '$ProdukID',
            '$Jumlah',
            '$Subtotal'
        )"
    );

    if (!$queryInsert) {
        die('Gagal tambah keranjang : ' . mysqli_error($koneksi));
    }
}

/*
|--------------------------------------------------------------------------
| Update Stok Produk
|--------------------------------------------------------------------------
*/
$StokBaru = $Stok - $Jumlah;

$queryStok = mysqli_query(
    $koneksi,
    "UPDATE produk SET
        Stok = '$StokBaru'
    WHERE ProdukID = '$ProdukID'"
);

if (!$queryStok) {
    die('Gagal update stok : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: transaksi_tambah.php");
exit;
?>