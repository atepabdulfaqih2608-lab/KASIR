<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$NamaPelanggan = trim($_POST['nm_pelanggan']);
$Alamat        = trim($_POST['alamat']);
$NomorTelepon  = trim($_POST['no_hp']);

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($NamaPelanggan) ||
    empty($Alamat) ||
    empty($NomorTelepon)
) {
    die('Semua data wajib diisi');
}

/*
|--------------------------------------------------------------------------
| Simpan Data
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "INSERT INTO pelanggan
    (
        NamaPelanggan,
        Alamat,
        NomorTelepon
    )
    VALUES
    (
        '$NamaPelanggan',
        '$Alamat',
        '$NomorTelepon'
    )"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal menambahkan pelanggan : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: pelanggan_data.php");
exit;
?>