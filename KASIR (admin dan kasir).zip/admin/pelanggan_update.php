<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$PelangganID   = trim($_POST['id_pelanggan']);
$NamaPelanggan = trim($_POST['nm_pelanggan']);
$Alamat        = trim($_POST['alamat']);
$NomorTelepon  = trim($_POST['no_hp']);

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($PelangganID) ||
    empty($NamaPelanggan) ||
    empty($Alamat) ||
    empty($NomorTelepon)
) {
    die('Data tidak lengkap');
}

/*
|--------------------------------------------------------------------------
| Update Data
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "UPDATE pelanggan SET
        NamaPelanggan = '$NamaPelanggan',
        Alamat        = '$Alamat',
        NomorTelepon  = '$NomorTelepon'
    WHERE PelangganID = '$PelangganID'"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal update pelanggan : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: pelanggan_data.php");
exit;
?>