<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Cek Session Login
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['UserID'])) {
    die('Session login tidak ditemukan');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$PenjualanID      = trim($_POST['no_trans']);
$TanggalPenjualan = trim($_POST['tanggal']);
$PelangganID      = trim($_POST['pelanggan']);
$TotalHarga       = trim($_POST['total']);

$UserID = $_SESSION['UserID'];

/*
|--------------------------------------------------------------------------
| Validasi Input
|--------------------------------------------------------------------------
*/
if (
    empty($PenjualanID) ||
    empty($TanggalPenjualan) ||
    empty($PelangganID)
) {
    die('Data transaksi tidak lengkap');
}

/*
|--------------------------------------------------------------------------
| Cek Keranjang
|--------------------------------------------------------------------------
*/
$queryDetail = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    WHERE PenjualanID = '$PenjualanID'"
);

if (mysqli_num_rows($queryDetail) == 0) {

    echo "
    <script>
        alert('Keranjang transaksi masih kosong!');
        window.location='transaksi_tambah.php';
    </script>
    ";

    exit;
}

/*
|--------------------------------------------------------------------------
| Hitung Ulang Total Dari Database
|--------------------------------------------------------------------------
*/
$queryTotal = mysqli_query(
    $koneksi,
    "SELECT SUM(Subtotal) AS GrandTotal
    FROM detailpenjualan
    WHERE PenjualanID = '$PenjualanID'"
);

$dataTotal = mysqli_fetch_array($queryTotal);

$GrandTotal = $dataTotal['GrandTotal'];

/*
|--------------------------------------------------------------------------
| Cek Transaksi Sudah Ada
|--------------------------------------------------------------------------
*/
$queryCek = mysqli_query(
    $koneksi,
    "SELECT *
    FROM penjualan
    WHERE PenjualanID = '$PenjualanID'"
);

if (mysqli_num_rows($queryCek) > 0) {

    echo "
    <script>
        alert('Transaksi sudah disimpan!');
        window.location='transaksi_data.php';
    </script>
    ";

    exit;
}

/*
|--------------------------------------------------------------------------
| Simpan Penjualan
|--------------------------------------------------------------------------
*/
$querySimpan = mysqli_query(
    $koneksi,
    "INSERT INTO penjualan
    (
        PenjualanID,
        TanggalPenjualan,
        TotalHarga,
        PelangganID,
        UserID
    )
    VALUES
    (
        '$PenjualanID',
        '$TanggalPenjualan',
        '$GrandTotal',
        '$PelangganID',
        '$UserID'
    )"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$querySimpan) {
    die('Gagal menyimpan transaksi : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
echo "
<script>
    alert('Transaksi berhasil disimpan!');
    window.location='transaksi_data.php';
</script>
";
exit;
?>