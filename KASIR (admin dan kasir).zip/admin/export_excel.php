<?php
require_once __DIR__ . '/../config/konek.php';

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=transaksi.xls");

$PenjualanID = $_GET['PenjualanID'];

$query = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    INNER JOIN produk
        ON produk.ProdukID = detailpenjualan.ProdukID
    WHERE PenjualanID = '$PenjualanID'"
);
?>

<table border="1">

    <tr>
        <th>No</th>
        <th>Produk</th>
        <th>Harga</th>
        <th>Jumlah</th>
        <th>Subtotal</th>
    </tr>

    <?php
    $no = 1;

    while ($data = mysqli_fetch_array($query)) {
    ?>

        <tr>

            <td><?= $no++; ?></td>

            <td><?= $data['NamaProduk']; ?></td>

            <td><?= $data['Harga']; ?></td>

            <td><?= $data['JumlahProduk']; ?></td>

            <td><?= $data['Subtotal']; ?></td>

        </tr>

    <?php } ?>

</table>
