<?php
include "header1.php";
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

$dataPelanggan = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM pelanggan"));
$dataProduk = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM produk"));
$dataTransaksi = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM penjualan"));

$queryTotal = mysqli_query($koneksi, "SELECT SUM(TotalHarga) AS total FROM penjualan");
$totalData = mysqli_fetch_array($queryTotal);
$totalTransaksi = $totalData['total'] ?? 0;
?>

<div class="content-wrapper">

<section class="content-header">
    <h1>Dashboard <small>Kasir Sederhana</small></h1>
</section>

<section class="content">

<div class="row">

<!-- ===================== PELANGGAN ===================== -->
<div class="col-md-3 col-sm-6 col-xs-12">
    <a href="pelanggan_data.php" style="color:inherit;">
        <div class="info-box" style="cursor:pointer;">
            <span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Data Pelanggan</span>
                <span class="info-box-number"><?= $dataPelanggan; ?></span>
            </div>
        </div>
    </a>
</div>

<!-- ===================== PRODUK ===================== -->
<div class="col-md-3 col-sm-6 col-xs-12">
    <a href="produk_data.php" style="color:inherit;">
        <div class="info-box" style="cursor:pointer;">
            <span class="info-box-icon bg-red"><i class="fa fa-cart-plus"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Data Produk</span>
                <span class="info-box-number"><?= $dataProduk; ?></span>
            </div>
        </div>
    </a>
</div>

<!-- ===================== TRANSAKSI ===================== -->
<div class="col-md-3 col-sm-6 col-xs-12">
    <a href="transaksi_data.php" style="color:inherit;">
        <div class="info-box" style="cursor:pointer;">
            <span class="info-box-icon bg-green"><i class="fa fa-bar-chart"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Data Transaksi</span>
                <span class="info-box-number"><?= $dataTransaksi; ?></span>
            </div>
        </div>
    </a>
</div>

<!-- ===================== TOTAL ===================== -->
<div class="col-md-3 col-sm-6 col-xs-12">
    <a href="transaksi_data.php" style="color:inherit;">
        <div class="info-box" style="cursor:pointer;">
            <span class="info-box-icon bg-yellow"><i class="fa fa-money"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Total Transaksi</span>
                <span class="info-box-number">
                    <?= "Rp. " . number_format($totalTransaksi, 0, ',', '.') . ",-"; ?>
                </span>
            </div>
        </div>
    </a>
</div>

</div>

</section>
</div>

<?php include "footer1.php"; ?>