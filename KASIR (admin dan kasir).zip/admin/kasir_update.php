<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data Form
|--------------------------------------------------------------------------
*/
$UserID   = $_POST['UserID'];
$NamaUser = trim($_POST['NamaUser']);
$username = trim($_POST['username']);
$role     = trim($_POST['role']);
$password = trim($_POST['password']);

/*
|--------------------------------------------------------------------------
| Validasi
|--------------------------------------------------------------------------
*/
if (
    empty($UserID) ||
    empty($NamaUser) ||
    empty($username) ||
    empty($role)
) {
    die('Data tidak lengkap');
}

/*
|--------------------------------------------------------------------------
| Update Dengan Password Baru
|--------------------------------------------------------------------------
*/
if (!empty($password)) {

    $passwordHash = md5($password);

    $query = mysqli_query(
        $koneksi,
        "UPDATE user SET
            NamaUser = '$NamaUser',
            username = '$username',
            password = '$passwordHash',
            role     = '$role'
        WHERE UserID = '$UserID'"
    );

} else {

    /*
    |--------------------------------------------------------------------------
    | Update Tanpa Password
    |--------------------------------------------------------------------------
    */

    $query = mysqli_query(
        $koneksi,
        "UPDATE user SET
            NamaUser = '$NamaUser',
            username = '$username',
            role     = '$role'
        WHERE UserID = '$UserID'"
    );
}

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal update user : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: kasir_data.php");
exit;
?>