<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Validasi ID
|--------------------------------------------------------------------------
*/
if (!isset($_GET['PenjualanID'])) {
    die('ID transaksi tidak ditemukan');
}

$PenjualanID = mysqli_real_escape_string(
    $koneksi,
    $_GET['PenjualanID']
);

/*
|--------------------------------------------------------------------------
| Ambil Data Penjualan
|--------------------------------------------------------------------------
*/
$queryPenjualan = mysqli_query(
    $koneksi,
    "SELECT *
    FROM penjualan
    INNER JOIN pelanggan
        ON pelanggan.PelangganID = penjualan.PelangganID
    INNER JOIN user
        ON user.UserID = penjualan.UserID
    WHERE penjualan.PenjualanID = '$PenjualanID'"
);

if (mysqli_num_rows($queryPenjualan) == 0) {
    die('Data transaksi tidak ditemukan');
}

$penjualan = mysqli_fetch_array($queryPenjualan);
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <title>Cetak Invoice</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            color: #333;
        }

        h1,
        h2,
        h3,
        h4,
        p {
            margin: 0;
        }

        .text-center {
            text-align: center;
        }

        .mb-20 {
            margin-bottom: 20px;
        }

        .mt-20 {
            margin-top: 20px;
        }

        .header {
            border-bottom: 3px solid #000;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header h2 {
            margin-bottom: 5px;
        }

        .info-table {
            width: 100%;
            margin-bottom: 20px;
        }

        .info-table td {
            padding: 5px;
            vertical-align: top;
        }

        .produk-table {
            width: 100%;
            border-collapse: collapse;
        }

        .produk-table th,
        .produk-table td {
            border: 1px solid #000;
            padding: 10px;
            font-size: 14px;
        }

        .produk-table th {
            background: #f2f2f2;
        }

        .total {
            font-size: 16px;
            font-weight: bold;
        }

        .footer {
            margin-top: 40px;
        }

        .btn-area {
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
            color: white;
            font-size: 14px;
        }

        .btn-print {
            background: #007bff;
        }

        .btn-excel {
            background: #28a745;
        }

        .btn-csv {
            background: #17a2b8;
        }

        .btn-back {
            background: #6c757d;
        }

        @media print {

            .btn-area {
                display: none;
            }

            body {
                margin: 10px;
            }
        }

    </style>

</head>

<body>

    <!-- ====================================== -->
    <!-- BUTTON -->
    <!-- ====================================== -->

    <div class="btn-area">

        <a href="#" onclick="window.print()" class="btn btn-print">
            Print
        </a>

        <a href="export_excel.php?PenjualanID=<?= $PenjualanID; ?>" class="btn btn-excel">
            Export Excel
        </a>

        <a href="export_csv.php?PenjualanID=<?= $PenjualanID; ?>" class="btn btn-csv">
            Export CSV
        </a>

        <a href="transaksi_data.php" class="btn btn-back">
            Kembali
        </a>

    </div>

    <!-- ====================================== -->
    <!-- HEADER -->
    <!-- ====================================== -->

    <div class="header text-center">

        <h2>KASIR SEDERHANA</h2>

        <p>
            Jl. Kertajati No. 123
        </p>
        
    </div>

    <!-- ====================================== -->
    <!-- INFORMASI TRANSAKSI -->
    <!-- ====================================== -->

    <table class="info-table">

        <tr>
            <td width="20%">No Transaksi</td>
            <td width="1%">:</td>
            <td><?= $penjualan['PenjualanID']; ?></td>
        </tr>

        <tr>
            <td>Tanggal</td>
            <td>:</td>
            <td><?= $penjualan['TanggalPenjualan']; ?></td>
        </tr>

        <tr>
            <td>Pelanggan</td>
            <td>:</td>
            <td><?= $penjualan['NamaPelanggan']; ?></td>
        </tr>

        <tr>
            <td>Kasir</td>
            <td>:</td>
            <td><?= $penjualan['NamaUser']; ?></td>
        </tr>

    </table>

    <!-- ====================================== -->
    <!-- DETAIL PRODUK -->
    <!-- ====================================== -->

    <table class="produk-table">

        <thead>

            <tr>
                <th width="5%">No</th>
                <th>Nama Produk</th>
                <th width="20%">Harga</th>
                <th width="10%">Qty</th>
                <th width="20%">Subtotal</th>
            </tr>

        </thead>

        <tbody>

            <?php

            $queryDetail = mysqli_query(
                $koneksi,
                "SELECT *
                FROM detailpenjualan
                INNER JOIN produk
                    ON produk.ProdukID = detailpenjualan.ProdukID
                WHERE detailpenjualan.PenjualanID = '$PenjualanID'"
            );

            $no = 1;

            while ($detail = mysqli_fetch_array($queryDetail)) {

            ?>

                <tr>

                    <td align="center">
                        <?= $no++; ?>
                    </td>

                    <td>
                        <?= $detail['NamaProduk']; ?>
                    </td>

                    <td>

                        Rp <?= number_format(
                                $detail['Harga'],
                                0,
                                ',',
                                '.'
                            ); ?>

                    </td>

                    <td align="center">
                        <?= $detail['JumlahProduk']; ?>
                    </td>

                    <td>

                        Rp <?= number_format(
                                $detail['Subtotal'],
                                0,
                                ',',
                                '.'
                            ); ?>

                    </td>

                </tr>

            <?php } ?>

        </tbody>

        <tfoot>

            <tr>

                <th colspan="4" align="right">
                    TOTAL
                </th>

                <th class="total">

                    Rp <?= number_format(
                            $penjualan['TotalHarga'],
                            0,
                            ',',
                            '.'
                        ); ?>

                </th>

            </tr>

        </tfoot>

    </table>

    <!-- ====================================== -->
    <!-- FOOTER -->
    <!-- ====================================== -->

    <div class="footer text-center">

        <p>
            Terima kasih telah berbelanja 🙏
        </p>

        <br>

        <p>
            Barang yang sudah dibeli tidak dapat dikembalikan
        </p>

    </div>

</body>

</html>