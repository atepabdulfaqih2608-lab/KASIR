<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| SORTING DATA PRODUK
|--------------------------------------------------------------------------
*/

$sort = $_GET['sort'] ?? '';

switch ($sort) {

    case 'abjad':
        $order = "ORDER BY NamaProduk ASC";
        break;

    case 'za':
        $order = "ORDER BY NamaProduk DESC";
        break;

    case 'terbaru':
        $order = "ORDER BY ProdukID DESC";
        break;

    case 'terlama':
        $order = "ORDER BY ProdukID ASC";
        break;

    case 'termahal':
        $order = "ORDER BY Harga DESC";
        break;

    case 'termurah':
        $order = "ORDER BY Harga ASC";
        break;

    case 'stok_terbanyak':
        $order = "ORDER BY Stok DESC";
        break;

    case 'stok_tersedikit':
        $order = "ORDER BY Stok ASC";
        break;

    default:
        $order = "ORDER BY ProdukID DESC";
        break;
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA PRODUK
|--------------------------------------------------------------------------
*/

$queryProduk = mysqli_query(
    $koneksi,
    "SELECT * FROM produk $order"
);
?>

<div class="content-wrapper">

    <!-- =========================================== -->
    <!-- HEADER -->
    <!-- =========================================== -->

    <section class="content-header">

        <h1>
            Data Produk
            <small>Kasir Sederhana</small>
        </h1>

        <ol class="breadcrumb">

            <li>
                <a href="#">
                    <i class="fa fa-dashboard"></i>
                    Dashboard
                </a>
            </li>

            <li class="active">
                Data Produk
            </li>

        </ol>

    </section>

    <!-- =========================================== -->
    <!-- CONTENT -->
    <!-- =========================================== -->

    <section class="content">

        <div class="box box-primary">

            <!-- HEADER BOX -->
            <div class="box-header">

                <button
                    type="button"
                    class="btn btn-primary"
                    data-toggle="modal"
                    data-target="#tambah-produk">

                    <i class="glyphicon glyphicon-plus"></i>
                    Tambah Produk

                </button>

            </div>

            <!-- BODY BOX -->
            <div class="box-body">

                <!-- SORTING -->
                <form method="GET" style="margin-bottom:15px; width:230px;">

                    <select
                        name="sort"
                        class="form-control"
                        onchange="this.form.submit()"
                    >

                        <option value=""
                            <?= ($sort == '') ? 'selected' : ''; ?>>
                            Urutkan Produk
                        </option>

                        <option value="abjad"
                            <?= ($sort == 'abjad') ? 'selected' : ''; ?>>
                            Nama A-Z
                        </option>

                        <option value="za"
                            <?= ($sort == 'za') ? 'selected' : ''; ?>>
                            Nama Z-A
                        </option>

                        <option value="terbaru"
                            <?= ($sort == 'terbaru') ? 'selected' : ''; ?>>
                            Produk Terbaru
                        </option>

                        <option value="terlama"
                            <?= ($sort == 'terlama') ? 'selected' : ''; ?>>
                            Produk Terlama
                        </option>

                        <option value="termahal"
                            <?= ($sort == 'termahal') ? 'selected' : ''; ?>>
                            Harga Termahal
                        </option>

                        <option value="termurah"
                            <?= ($sort == 'termurah') ? 'selected' : ''; ?>>
                            Harga Termurah
                        </option>

                        <option value="stok_terbanyak"
                            <?= ($sort == 'stok_terbanyak') ? 'selected' : ''; ?>>
                            Stok Terbanyak
                        </option>

                        <option value="stok_tersedikit"
                            <?= ($sort == 'stok_tersedikit') ? 'selected' : ''; ?>>
                            Stok Tersedikit
                        </option>

                    </select>

                </form>

                <!-- TABEL -->
                <table class="table table-bordered table-striped">

                    <thead>

                        <tr>
                            <th width="5%">NO</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th width="15%">Opsi</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php
                        $no = 1;

                        while ($produk = mysqli_fetch_array($queryProduk)) {
                        ?>

                            <tr>

                                <td><?= $no++; ?></td>

                                <td>
                                    <?= $produk['NamaProduk']; ?>
                                </td>

                                <td>
                                    Rp <?= number_format($produk['Harga'], 0, ',', '.'); ?>
                                </td>

                                <td>
                                    <?= $produk['Stok']; ?>
                                </td>

                                <td>

                                    <!-- EDIT -->
                                    <button
                                        class="btn btn-warning btn-xs"
                                        data-toggle="modal"
                                        data-target="#edit<?= $produk['ProdukID']; ?>">

                                        <i class="glyphicon glyphicon-edit"></i>

                                    </button>

                                    <!-- HAPUS -->
                                    <a href="produk_hapus.php?ProdukID=<?= $produk['ProdukID']; ?>"
                                        class="btn btn-danger btn-xs"
                                        onclick="return confirm('Yakin ingin menghapus produk ini?')">

                                        <i class="glyphicon glyphicon-trash"></i>

                                    </a>

                                </td>

                            </tr>

                            <!-- MODAL EDIT -->
                            <div class="modal fade"
                                id="edit<?= $produk['ProdukID']; ?>">

                                <div class="modal-dialog">

                                    <div class="modal-content">

                                        <div class="modal-header">

                                            <button
                                                type="button"
                                                class="close"
                                                data-dismiss="modal">

                                                &times;

                                            </button>

                                            <h4 class="modal-title">
                                                Edit Produk
                                            </h4>

                                        </div>

                                        <div class="modal-body">

                                            <form action="produk_update.php"
                                                method="POST">

                                                <input type="hidden"
                                                    name="ProdukID"
                                                    value="<?= $produk['ProdukID']; ?>">

                                                <!-- Nama Produk -->
                                                <div class="form-group">

                                                    <label>
                                                        Nama Produk
                                                    </label>

                                                    <input type="text"
                                                        name="NamaProduk"
                                                        class="form-control"
                                                        value="<?= $produk['NamaProduk']; ?>"
                                                        required>

                                                </div>

                                                <!-- Harga -->
                                                <div class="form-group">

                                                    <label>
                                                        Harga
                                                    </label>

                                                    <input type="number"
                                                        name="Harga"
                                                        class="form-control"
                                                        value="<?= $produk['Harga']; ?>"
                                                        min="0"
                                                        required>

                                                </div>

                                                <!-- Stok -->
                                                <div class="form-group">

                                                    <label>
                                                        Stok
                                                    </label>

                                                    <input type="number"
                                                        name="Stok"
                                                        class="form-control"
                                                        value="<?= $produk['Stok']; ?>"
                                                        min="0"
                                                        required>

                                                </div>

                                                <button type="submit"
                                                    class="btn btn-primary">

                                                    Update

                                                </button>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>

<!-- =============================================== -->
<!-- MODAL TAMBAH -->
<!-- =============================================== -->

<div class="modal fade" id="tambah-produk">

    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">

                <button
                    type="button"
                    class="close"
                    data-dismiss="modal">

                    &times;

                </button>

                <h4 class="modal-title">
                    Tambah Produk
                </h4>

            </div>

            <div class="modal-body">

                <form action="produk_tambah.php"
                    method="POST">

                    <!-- Nama Produk -->
                    <div class="form-group">

                        <label>
                            Nama Produk
                        </label>

                        <input type="text"
                            name="NamaProduk"
                            class="form-control"
                            required>

                    </div>

                    <!-- Harga -->
                    <div class="form-group">

                        <label>
                            Harga
                        </label>

                        <input type="number"
                            name="Harga"
                            class="form-control"
                            min="0"
                            required>

                    </div>

                    <!-- Stok -->
                    <div class="form-group">

                        <label>
                            Stok
                        </label>

                        <input type="number"
                            name="Stok"
                            class="form-control"
                            min="0"
                            required>

                    </div>

                    <button type="submit"
                        class="btn btn-primary">

                        Simpan

                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

<?php include "footer1.php"; ?>