
<?php
require_once __DIR__ . '/../config/konek.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="Laporan_Transaksi.csv"');

$dari   = $_GET['dari'] ?? '';
$sampai = $_GET['sampai'] ?? '';

$query = "
    SELECT
        penjualan.*,
        pelanggan.NamaPelanggan,
        user.NamaUser
    FROM penjualan

    LEFT JOIN pelanggan
        ON pelanggan.PelangganID = penjualan.PelangganID

    LEFT JOIN user
        ON user.UserID = penjualan.UserID
";

if ($dari != '' && $sampai != '') {

    $query .= "
        WHERE DATE(penjualan.TanggalPenjualan)
        BETWEEN '$dari' AND '$sampai'
    ";
}

$query .= "
    ORDER BY penjualan.PenjualanID DESC
";

$data = mysqli_query($koneksi, $query);

$output = fopen('php://output', 'w');

fputcsv($output, [
    'NO',
    'NOMOR TRANSAKSI',
    'TANGGAL',
    'PELANGGAN',
    'PETUGAS',
    'TOTAL'
]);

$no = 1;
$grandTotal = 0;

while ($row = mysqli_fetch_array($data)) {

    $grandTotal += $row['TotalHarga'];

    fputcsv($output, [
        $no++,
        $row['PenjualanID'],
        $row['TanggalPenjualan'],
        $row['NamaPelanggan'],
        $row['NamaUser'],
        $row['TotalHarga']
    ]);
}

fputcsv($output, [
    '',
    '',
    '',
    '',
    'TOTAL',
    $grandTotal
]);

fclose($output);
exit;
