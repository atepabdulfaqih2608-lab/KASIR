<?php
require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Validasi ID
|--------------------------------------------------------------------------
*/
if (!isset($_GET['PelangganID'])) {
    die('PelangganID tidak ditemukan');
}

$PelangganID = $_GET['PelangganID'];

/*
|--------------------------------------------------------------------------
| Hapus Data
|--------------------------------------------------------------------------
*/
$query = mysqli_query(
    $koneksi,
    "DELETE FROM pelanggan
    WHERE PelangganID = '$PelangganID'"
);

/*
|--------------------------------------------------------------------------
| Cek Query
|--------------------------------------------------------------------------
*/
if (!$query) {
    die('Gagal menghapus pelanggan : ' . mysqli_error($koneksi));
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
header("Location: pelanggan_data.php");
exit;
?>