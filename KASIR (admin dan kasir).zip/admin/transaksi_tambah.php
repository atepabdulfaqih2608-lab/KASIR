<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized');
}

/*
|--------------------------------------------------------------------------
| Generate Nomor Transaksi
|--------------------------------------------------------------------------
*/
$queryKode = mysqli_query(
    $koneksi,
    "SELECT MAX(PenjualanID) AS terakhir
    FROM penjualan"
);

$dataKode = mysqli_fetch_array($queryKode);

$kodeLama = $dataKode['terakhir'];

if ($kodeLama) {

    $urutan = (int) substr($kodeLama, -4);
    $urutan++;

} else {

    $urutan = 1;
}

$tanggal = date('ymd');

$PenjualanID = $tanggal . sprintf("%04s", $urutan);

/*
|--------------------------------------------------------------------------
| Ambil Data Keranjang
|--------------------------------------------------------------------------
*/
$queryKeranjang = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    INNER JOIN produk
        ON produk.ProdukID = detailpenjualan.ProdukID
    WHERE detailpenjualan.PenjualanID = '$PenjualanID'
"
);

$total = 0;
?>

<div class="content-wrapper">

    <!-- ====================================== -->
    <!-- HEADER -->
    <!-- ====================================== -->

    <section class="content-header">

        <h1>
            Tambah Transaksi
            <small>Kasir Sederhana</small>
        </h1>

    </section>

    <!-- ====================================== -->
    <!-- CONTENT -->
    <!-- ====================================== -->

    <section class="content">

        <div class="row">

            <!-- ====================================== -->
            <!-- TABEL KERANJANG -->
            <!-- ====================================== -->

            <div class="col-md-8">

                <div class="box box-primary">

                    <div class="box-header">

                        <button type="button"
                            class="btn btn-primary"
                            data-toggle="modal"
                            data-target="#modalTambah">

                            <i class="glyphicon glyphicon-plus"></i>
                            Tambah Barang

                        </button>

                    </div>

                    <div class="box-body">

                        <table class="table table-bordered table-striped">

                            <thead>

                                <tr>
                                    <th width="5%">NO</th>
                                    <th>Nama Produk</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Subtotal</th>
                                    <th width="10%">Opsi</th>
                                </tr>

                            </thead>

                            <tbody>

                                <?php
                                $no = 1;

                                while ($data = mysqli_fetch_array($queryKeranjang)) {

                                    $total += $data['Subtotal'];
                                ?>

                                    <tr>

                                        <td><?= $no++; ?></td>

                                        <td>
                                            <?= $data['NamaProduk']; ?>
                                        </td>

                                        <td>

                                            Rp
                                            <?= number_format(
                                                $data['Harga'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </td>

                                        <td>
                                            <?= $data['JumlahProduk']; ?>
                                        </td>

                                        <td>

                                            Rp
                                            <?= number_format(
                                                $data['Subtotal'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </td>

                                        <td>

                                            <a href="transaksi_hapus_item.php?DetailID=<?= $data['DetailID']; ?>"
                                                class="btn btn-danger btn-xs"
                                                onclick="return confirm('Yakin hapus item ini?')">

                                                <i class="glyphicon glyphicon-trash"></i>

                                            </a>

                                        </td>

                                    </tr>

                                <?php } ?>

                            </tbody>

                            <tfoot>

                                <tr>

                                    <th colspan="4">
                                        Total Belanja
                                    </th>

                                    <th colspan="2">

                                        Rp
                                        <?= number_format(
                                            $total,
                                            0,
                                            ',',
                                            '.'
                                        ); ?>

                                    </th>

                                </tr>

                            </tfoot>

                        </table>

                    </div>

                </div>

            </div>

            <!-- ====================================== -->
            <!-- FORM SIMPAN -->
            <!-- ====================================== -->

            <div class="col-md-4">

                <div class="box box-success">

                    <div class="box-header">

                        <h3 class="box-title">
                            Simpan Transaksi
                        </h3>

                    </div>

                    <div class="box-body">

                        <form action="transaksi_proses.php" method="POST">

                            <div class="form-group">

                                <label>No Transaksi</label>

                                <input type="text"
                                    name="no_trans"
                                    class="form-control"
                                    value="<?= $PenjualanID; ?>"
                                    readonly>

                            </div>

                            <div class="form-group">

                                <label>Tanggal</label>

                                <input type="date"
                                    name="tanggal"
                                    class="form-control"
                                    value="<?= date('Y-m-d'); ?>"
                                    readonly>

                            </div>

                            <div class="form-group">

                                <label>Kasir</label>

                                <?php
                                $UserID = $_SESSION['UserID'];

                                $queryUser = mysqli_query(
                                    $koneksi,
                                    "SELECT *
                                    FROM user
                                    WHERE UserID = '$UserID'"
                                );

                                $user = mysqli_fetch_array($queryUser);
                                ?>

                                <input type="text"
                                    class="form-control"
                                    value="<?= $user['NamaUser']; ?>"
                                    readonly>

                            </div>

                            <div class="form-group">

                                <label>Pilih Pelanggan</label>

                                <select name="pelanggan"
                                    class="form-control"
                                    required>

                                    <option value="">
                                        -- Pilih Pelanggan --
                                    </option>

                                    <?php
                                    $queryPelanggan = mysqli_query(
                                        $koneksi,
                                        "SELECT *
                                        FROM pelanggan
                                        ORDER BY NamaPelanggan ASC"
                                    );

                                    while ($pelanggan = mysqli_fetch_array($queryPelanggan)) {
                                    ?>

                                        <option value="<?= $pelanggan['PelangganID']; ?>">

                                            <?= $pelanggan['NamaPelanggan']; ?>

                                        </option>

                                    <?php } ?>

                                </select>

                            </div>

                            <input type="hidden"
                                name="total"
                                value="<?= $total; ?>">

                            <button type="submit"
                                class="btn btn-success btn-block">

                                <i class="glyphicon glyphicon-floppy-disk"></i>
                                Simpan Transaksi

                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </section>

</div>

<!-- ====================================== -->
<!-- MODAL TAMBAH BARANG -->
<!-- ====================================== -->

<div class="modal fade" id="modalTambah">

    <div class="modal-dialog">

        <div class="modal-content">

            <form action="transaksi_detail_proses.php"
                method="POST">

                <div class="modal-header">

                    <button type="button"
                        class="close"
                        data-dismiss="modal">

                        &times;

                    </button>

                    <h4 class="modal-title">
                        Tambah Barang
                    </h4>

                </div>

                <div class="modal-body">

                    <div class="form-group">

                        <label>No Transaksi</label>

                        <input type="text"
                            name="no_trans"
                            class="form-control"
                            value="<?= $PenjualanID; ?>"
                            readonly>

                    </div>

                    <div class="form-group">

                        <label>Pilih Produk</label>

                        <select name="produk"
                            class="form-control"
                            required>

                            <option value="">
                                -- Pilih Produk --
                            </option>

                            <?php
                            $queryProduk = mysqli_query(
                                $koneksi,
                                "SELECT *
                                FROM produk
                                ORDER BY NamaProduk ASC"
                            );

                            while ($produk = mysqli_fetch_array($queryProduk)) {
                            ?>

                                <option value="<?= $produk['ProdukID']; ?>">

                                    <?= $produk['NamaProduk']; ?>
                                    (Stok: <?= $produk['Stok']; ?>)

                                </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="form-group">

                        <label>Jumlah</label>

                        <input type="number"
                            name="jumlah"
                            class="form-control"
                            min="1"
                            required>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="submit"
                        class="btn btn-primary">

                        <i class="glyphicon glyphicon-plus"></i>
                        Tambah

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<?php include "footer1.php"; ?>