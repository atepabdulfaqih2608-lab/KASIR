<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Koneksi database gagal');
}

/*
|--------------------------------------------------------------------------
| Ambil ID Transaksi
|--------------------------------------------------------------------------
*/
if (!isset($_GET['PenjualanID'])) {
    die('ID transaksi tidak ditemukan');
}

$PenjualanID = $_GET['PenjualanID'];

/*
|--------------------------------------------------------------------------
| Ambil Data Penjualan
|--------------------------------------------------------------------------
*/
$queryPenjualan = mysqli_query(
    $koneksi,
    "SELECT *
    FROM penjualan
    INNER JOIN pelanggan
        ON pelanggan.PelangganID = penjualan.PelangganID
    INNER JOIN user
        ON user.UserID = penjualan.UserID
    WHERE penjualan.PenjualanID = '$PenjualanID'"
);

if (mysqli_num_rows($queryPenjualan) == 0) {
    die('Data transaksi tidak ditemukan');
}

$penjualan = mysqli_fetch_array($queryPenjualan);
?>

<div class="content-wrapper">

    <!-- ====================================== -->
    <!-- HEADER -->
    <!-- ====================================== -->

    <section class="content-header">

        <h1>
            Detail Transaksi
            <small><?= $PenjualanID; ?></small>
        </h1>

    </section>

    <!-- ====================================== -->
    <!-- CONTENT -->
    <!-- ====================================== -->

    <section class="content">

        <div class="row">

            <!-- ====================================== -->
            <!-- INFORMASI TRANSAKSI -->
            <!-- ====================================== -->

            <div class="col-md-4">

                <div class="box box-primary">

                    <div class="box-header">
                        <h3 class="box-title">
                            Informasi Transaksi
                        </h3>
                    </div>

                    <div class="box-body">

                        <table class="table">

                            <tr>
                                <th>No Transaksi</th>
                                <td><?= $penjualan['PenjualanID']; ?></td>
                            </tr>

                            <tr>
                                <th>Tanggal</th>
                                <td><?= $penjualan['TanggalPenjualan']; ?></td>
                            </tr>

                            <tr>
                                <th>Pelanggan</th>
                                <td><?= $penjualan['NamaPelanggan']; ?></td>
                            </tr>

                            <tr>
                                <th>Kasir</th>
                                <td><?= $penjualan['NamaUser']; ?></td>
                            </tr>

                            <tr>
                                <th>Total</th>
                                <td>
                                    <strong>
                                        Rp
                                        <?= number_format(
                                            $penjualan['TotalHarga'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>
                                    </strong>
                                </td>
                            </tr>

                        </table>

                    </div>

                </div>

            </div>

            <!-- ====================================== -->
            <!-- DETAIL BARANG -->
            <!-- ====================================== -->

            <div class="col-md-8">

                <div class="box box-success">

                    <div class="box-header">

                        <h3 class="box-title">
                            Detail Barang
                        </h3>

                    </div>

                    <div class="box-body">

                        <table class="table table-bordered table-striped">

                            <thead>

                                <tr>
                                    <th width="5%">NO</th>
                                    <th>Nama Produk</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                    <th>Subtotal</th>
                                </tr>

                            </thead>

                            <tbody>

                                <?php
                                $queryDetail = mysqli_query(
                                    $koneksi,
                                    "SELECT *
                                    FROM detailpenjualan
                                    INNER JOIN produk
                                        ON produk.ProdukID = detailpenjualan.ProdukID
                                    WHERE detailpenjualan.PenjualanID = '$PenjualanID'"
                                );

                                $no = 1;

                                while ($detail = mysqli_fetch_array($queryDetail)) {
                                ?>

                                    <tr>

                                        <td><?= $no++; ?></td>

                                        <td>
                                            <?= $detail['NamaProduk']; ?>
                                        </td>

                                        <td>

                                            Rp
                                            <?= number_format(
                                                $detail['Harga'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </td>

                                        <td>
                                            <?= $detail['JumlahProduk']; ?>
                                        </td>

                                        <td>

                                            Rp
                                            <?= number_format(
                                                $detail['Subtotal'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </td>

                                    </tr>

                                <?php } ?>

                            </tbody>

                            <tfoot>

                                <tr>

                                    <th colspan="4">
                                        Total Belanja
                                    </th>

                                    <th>

                                        Rp
                                        <?= number_format(
                                            $penjualan['TotalHarga'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>

                                    </th>

                                </tr>

                            </tfoot>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </section>

</div>

<?php include "footer1.php"; ?>
