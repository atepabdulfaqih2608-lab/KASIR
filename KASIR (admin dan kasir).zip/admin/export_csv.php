<?php
require_once __DIR__ . '/../config/konek.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="transaksi.csv"');

$output = fopen('php://output', 'w');

fputcsv($output, [
    'No',
    'Produk',
    'Harga',
    'Jumlah',
    'Subtotal'
]);

$PenjualanID = $_GET['PenjualanID'];

$query = mysqli_query(
    $koneksi,
    "SELECT *
    FROM detailpenjualan
    INNER JOIN produk
        ON produk.ProdukID = detailpenjualan.ProdukID
    WHERE PenjualanID = '$PenjualanID'"
);

$no = 1;

while ($data = mysqli_fetch_array($query)) {

    fputcsv($output, [
        $no++,
        $data['NamaProduk'],
        $data['Harga'],
        $data['JumlahProduk'],
        $data['Subtotal']
    ]);
}

fclose($output);
?>
