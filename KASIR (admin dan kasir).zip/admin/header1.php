<?php
session_start();

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Cek Login
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['role']) || empty($_SESSION['role'])) {
    header("Location: ../index.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| Ambil Data User Login
|--------------------------------------------------------------------------
*/
$UserID = $_SESSION['UserID'];

$queryUser = mysqli_query(
    $koneksi,
    "SELECT * FROM user WHERE UserID = '$UserID'"
);

$user = mysqli_fetch_array($queryUser);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Kasir Sederhana</title>

    <!-- Responsive -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- Bootstrap -->
    <link rel="stylesheet"
        href="../assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet"
        href="../assets/bower_components/font-awesome/css/font-awesome.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet"
        href="../assets/bower_components/Ionicons/css/ionicons.min.css">

    <!-- jvectormap -->
    <link rel="stylesheet"
        href="../assets/bower_components/jvectormap/jquery-jvectormap.css">

    <!-- Theme style -->
    <link rel="stylesheet"
        href="../assets/dist/css/AdminLTE.min.css">

    <!-- AdminLTE Skins -->
    <link rel="stylesheet"
        href="../assets/dist/css/skins/_all-skins.min.css">

    <!-- Google Font -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700">
</head>

<body class="hold-transition skin-blue sidebar-mini">

    <div class="wrapper">

        <!-- =============================================== -->
        <!-- HEADER -->
        <!-- =============================================== -->

        <header class="main-header">

            <!-- Logo -->
            <a href="index1.php" class="logo">

                <!-- Mini Logo -->
                <span class="logo-mini">
                    <b>K</b>s
                </span>

                <!-- Logo Desktop -->
                <span class="logo-lg">
                    <b>Kasir</b>skti
                </span>

            </a>

            <!-- Navbar -->
            <nav class="navbar navbar-static-top">

                <!-- Sidebar Toggle -->
                <a href="#"
                    class="sidebar-toggle"
                    data-toggle="push-menu"
                    role="button">

                    <span class="sr-only">
                        Toggle navigation
                    </span>

                </a>

                <!-- Navbar Right -->
                <div class="navbar-custom-menu">

                    <ul class="nav navbar-nav">

                        <!-- User -->
                        <li class="dropdown user user-menu">

                            <a href="#"
                                class="dropdown-toggle"
                                data-toggle="dropdown">

                                <img src="../assets/dist/img/user2-160x160.jpg"
                                    class="user-image"
                                    alt="User Image">

                                <span class="hidden-xs">
                                    <?= $user['NamaUser']; ?>
                                </span>

                            </a>

                            <ul class="dropdown-menu">

                                <!-- User Image -->
                                <li class="user-header">

                                    <img src="../assets/dist/img/user2-160x160.jpg"
                                        class="img-circle"
                                        alt="User Image">

                                    <p>
                                        <?= $user['NamaUser']; ?>

                                        <small>
                                            Username :
                                            <?= $user['username']; ?>
                                        </small>
                                    </p>

                                </li>

                                <!-- Footer -->
                                <li class="user-footer">

                                    <div class="pull-right">

                                        <a href="logout.php"
                                            class="btn btn-danger btn-flat">

                                            Sign Out

                                        </a>

                                    </div>

                                </li>

                            </ul>

                        </li>

                    </ul>

                </div>

            </nav>

        </header>

        <!-- =============================================== -->
        <!-- SIDEBAR -->
        <!-- =============================================== -->

        <aside class="main-sidebar">

            <section class="sidebar">

                <!-- User Panel -->
                <div class="user-panel">

                    <div class="pull-left image">

                        <img src="../assets/dist/img/user2-160x160.jpg"
                            class="img-circle"
                            alt="User Image">

                    </div>

                    <div class="pull-left info">

                        <p>
                            <?= $user['NamaUser']; ?>
                        </p>

                        <a href="#">
                            <i class="fa fa-circle text-success"></i>
                            Online
                        </a>

                    </div>

                </div>

                <!-- Menu -->
                <ul class="sidebar-menu" data-widget="tree">

                    <li class="header">
                        MAIN NAVIGATION
                    </li>

                    <!-- Dashboard -->
                    <li>
                        <a href="index1.php">
                            <i class="fa fa-dashboard"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <!-- Master Data -->
                    <li class="treeview">

                        <a href="#">
                            <i class="fa fa-database"></i>

                            <span>Master Data</span>

                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>

                        <ul class="treeview-menu">

                            <li>
                                <a href="pelanggan_data.php">
                                    <i class="fa fa-circle-o"></i>
                                    Data Pelanggan
                                </a>
                            </li>

                            <li>
                                <a href="produk_data.php">
                                    <i class="fa fa-circle-o"></i>
                                    Data Produk
                                </a>
                            </li>

                            <li>
                                <a href="kasir_data.php">
                                    <i class="fa fa-circle-o"></i>
                                    Data Kasir
                                </a>
                            </li>

                        </ul>

                    </li>

                    <!-- Transaksi -->
                    <li class="treeview">

                        <a href="#">

                            <i class="fa fa-money"></i>

                            <span>Transaksi</span>

                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>

                        </a>

                        <ul class="treeview-menu">

                            <li>
                                <a href="transaksi_data.php">
                                    <i class="fa fa-circle-o"></i>
                                    Data Transaksi
                                </a>
                            </li>

                            <li>
                                <a href="transaksi_tambah.php">
                                    <i class="fa fa-circle-o"></i>
                                    Tambah Transaksi
                                </a>
                            </li>

                        </ul>

                    </li>

                    <!-- Laporan -->
                    <li>
                        <a href="transaksi_laporan.php">

                            <i class="fa fa-book"></i>

                            <span>
                                Laporan Transaksi
                            </span>

                        </a>
                    </li>

                </ul>

            </section>

        </aside>