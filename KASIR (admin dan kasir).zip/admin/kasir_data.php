<?php
include "header1.php";

require_once __DIR__ . '/../config/konek.php';

if (!isset($koneksi)) {
    die('Database connection not initialized in konek.php');
}

/*
|--------------------------------------------------------------------------
| Ambil Data User
|--------------------------------------------------------------------------
*/
$queryUser = mysqli_query(
    $koneksi,
    "SELECT * FROM user ORDER BY UserID DESC"
);
?>

<!-- =============================================== -->
<!-- CONTENT -->
<!-- =============================================== -->

<div class="content-wrapper">

    <!-- =========================================== -->
    <!-- HEADER -->
    <!-- =========================================== -->

    <section class="content-header">

        <h1>
            Data Kasir
            <small>Manajemen User</small>
        </h1>

        <ol class="breadcrumb">

            <li>
                <a href="#">
                    <i class="fa fa-dashboard"></i>
                    Dashboard
                </a>
            </li>

            <li class="active">
                Data Kasir
            </li>

        </ol>

    </section>

    <!-- =========================================== -->
    <!-- MAIN CONTENT -->
    <!-- =========================================== -->

    <section class="content">

        <div class="box box-primary">

            <!-- =================================== -->
            <!-- HEADER BOX -->
            <!-- =================================== -->

            <div class="box-header">

                <button
                    class="btn btn-primary"
                    data-toggle="modal"
                    data-target="#tambah-user">

                    <i class="glyphicon glyphicon-plus"></i>
                    Tambah User

                </button>

            </div>

            <!-- =================================== -->
            <!-- BODY BOX -->
            <!-- =================================== -->

            <div class="box-body">

                <table class="table table-bordered table-striped">

                    <thead>

                        <tr>
                            <th width="5%">NO</th>
                            <th>Nama User</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th width="15%">Opsi</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php
                        $no = 1;

                        while ($data = mysqli_fetch_array($queryUser)) {
                        ?>

                            <tr>

                                <td><?= $no++; ?></td>

                                <td>
                                    <?= $data['NamaUser']; ?>
                                </td>

                                <td>
                                    <?= $data['username']; ?>
                                </td>

                                <td>
                                    <?= $data['role']; ?>
                                </td>

                                <td>

                                    <!-- EDIT -->
                                    <button
                                        class="btn btn-warning btn-xs"
                                        data-toggle="modal"
                                        data-target="#edit<?= $data['UserID']; ?>">

                                        <i class="glyphicon glyphicon-edit"></i>

                                    </button>

                                    <!-- HAPUS -->
                                    <a href="kasir_hapus.php?UserID=<?= $data['UserID']; ?>"
                                        class="btn btn-danger btn-xs"
                                        onclick="return confirm('Yakin ingin menghapus user ini?')">

                                        <i class="glyphicon glyphicon-trash"></i>

                                    </a>

                                </td>

                            </tr>

                            <!-- =================================== -->
                            <!-- MODAL EDIT -->
                            <!-- =================================== -->

                            <div class="modal fade"
                                id="edit<?= $data['UserID']; ?>">

                                <div class="modal-dialog">

                                    <div class="modal-content">

                                        <div class="modal-header">

                                            <button type="button"
                                                class="close"
                                                data-dismiss="modal">

                                                &times;

                                            </button>

                                            <h4 class="modal-title">
                                                Edit User
                                            </h4>

                                        </div>

                                        <div class="modal-body">

                                            <form action="kasir_update.php"
                                                method="POST">

                                                <input type="hidden"
                                                    name="UserID"
                                                    value="<?= $data['UserID']; ?>">

                                                <!-- Nama User -->
                                                <div class="form-group">

                                                    <label>
                                                        Nama User
                                                    </label>

                                                    <input type="text"
                                                        name="NamaUser"
                                                        class="form-control"
                                                        value="<?= $data['NamaUser']; ?>"
                                                        required>

                                                </div>

                                                <!-- Username -->
                                                <div class="form-group">

                                                    <label>
                                                        Username
                                                    </label>

                                                    <input type="text"
                                                        name="username"
                                                        class="form-control"
                                                        value="<?= $data['username']; ?>"
                                                        required>

                                                </div>

                                                <!-- Password -->
                                                <div class="form-group">

                                                    <label>
                                                        Password
                                                    </label>

                                                    <input type="password"
                                                        name="password"
                                                        class="form-control"
                                                        placeholder="Kosongkan jika tidak diubah">

                                                </div>

                                                <!-- Role -->
                                                <div class="form-group">

                                                    <label>
                                                        Role
                                                    </label>

                                                    <select name="role"
                                                        class="form-control"
                                                        required>

                                                        <option value="Admin"
                                                            <?= ($data['role'] == 'Admin') ? 'selected' : ''; ?>>

                                                            Admin

                                                        </option>

                                                        <option value="Kasir"
                                                            <?= ($data['role'] == 'Kasir') ? 'selected' : ''; ?>>

                                                            Kasir

                                                        </option>

                                                    </select>

                                                </div>

                                                <button type="submit"
                                                    class="btn btn-primary">

                                                    Update

                                                </button>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>

<!-- =============================================== -->
<!-- MODAL TAMBAH USER -->
<!-- =============================================== -->

<div class="modal fade" id="tambah-user">

    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">

                <button type="button"
                    class="close"
                    data-dismiss="modal">

                    &times;

                </button>

                <h4 class="modal-title">
                    Tambah User
                </h4>

            </div>

            <div class="modal-body">

                <form action="kasir_tambah.php"
                    method="POST">

                    <!-- Nama User -->
                    <div class="form-group">

                        <label>
                            Nama User
                        </label>

                        <input type="text"
                            name="NamaUser"
                            class="form-control"
                            required>

                    </div>

                    <!-- Username -->
                    <div class="form-group">

                        <label>
                            Username
                        </label>

                        <input type="text"
                            name="username"
                            class="form-control"
                            required>

                    </div>

                    <!-- Password -->
                    <div class="form-group">

                        <label>
                            Password
                        </label>

                        <input type="password"
                            name="password"
                            class="form-control"
                            required>

                    </div>

                    <!-- Role -->
                    <div class="form-group">

                        <label>
                            Role
                        </label>

                        <select name="role"
                            class="form-control"
                            required>

                            <option value="Admin">
                                Admin
                            </option>

                            <option value="Kasir">
                                Kasir
                            </option>

                        </select>

                    </div>

                    <button type="submit"
                        class="btn btn-primary">

                        Simpan

                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

<?php include "footer1.php"; ?>